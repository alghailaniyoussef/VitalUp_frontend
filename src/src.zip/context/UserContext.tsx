// UserContext.tsx
import { useEffect, useState, createContext, useContext } from 'react';

export interface User {
    id: number;
    name: string;
    email: string;
}

interface UserContextType {
    user: User | null | undefined;
    setUser: (user: User | null) => void;
    isLoading: boolean;
}

const UserContext = createContext<UserContextType>({
    user: undefined,
    setUser: () => {},
    isLoading: true,
});

export const useUser = () => useContext(UserContext);

export const UserProvider = ({ children }: { children: React.ReactNode }) => {
    const [user, setUser] = useState<User | null | undefined>(undefined);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        // Check for cached user data first
        const cachedUser = localStorage.getItem('auth_user');
        if (cachedUser && cachedUser !== 'undefined' && cachedUser !== 'null') {
            try {
                setUser(JSON.parse(cachedUser));
            } catch (error) {
                console.error("Error parsing cached user:", error);
                localStorage.removeItem('auth_user');
            }
        }

        const fetchUser = async () => {
            try {
                const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/user`, {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                    }
                });

                if (res.ok) {
                    const data = await res.json();
                    console.log("✅ User authenticated:", data);
                    setUser(data.user);
                    localStorage.setItem('auth_user', JSON.stringify(data.user));
                } else {
                    console.log("User not authenticated");
                    setUser(null);
                    localStorage.removeItem('auth_user');
                }
            } catch (err) {
                console.error("Error fetching user:", err);
                setUser(null);
                localStorage.removeItem('auth_user');
            } finally {
                setIsLoading(false);
            }
        };

        fetchUser();
    }, []);

    return (
        <UserContext.Provider value={{ user, setUser, isLoading }}>
            {children}
        </UserContext.Provider>
    );
};