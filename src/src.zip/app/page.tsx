import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <section className="flex flex-col md:flex-row items-center justify-between px-8 py-16 bg-gradient-to-r from-blue-50 to-blue-100">
      <div className="max-w-xl space-y-6">
        <h2 className="text-4xl md:text-5xl font-extrabold text-blue-800">Bienvenido a tu espacio de bienestar</h2>
        <p className="text-lg text-gray-700">
          Recibe recordatorios personalizados sobre salud física y emocional. Participa en desafíos, acumula puntos y mejora tu bienestar cada día.
        </p>
        <div className="space-x-4">
          <Link href="/auth/register" className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">Comenzar ahora</Link>
          <Link href="/features" className="text-blue-600 hover:underline">Explorar funciones</Link>
        </div>
      </div>
      <div className="mt-10 md:mt-0 md:ml-10">
        <Image
          src="/images/wellness-hero.png"
          alt="Ilustración salud y bienestar"
          width={500}
          height={400}
          className="rounded-lg shadow-lg"
        />
      </div>
    </section>
  );
}
