'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function Dashboard() {
    const [user, setUser] = useState(null);
    const [dashboard, setDashboard] = useState(null);
    const [loading, setLoading] = useState(true);
    const router = useRouter();

    useEffect(() => {
        const fetchUserAndDashboard = async () => {
            try {
                const userRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/user`, {
                    credentials: 'include',
                });
                if (!userRes.ok) throw new Error('Not authenticated');
                const userData = await userRes.json();
                setUser(userData);

                const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/dashboard-data`, {
                    method: 'GET',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                });

                if (!res.ok) throw new Error('Fallo al obtener los datos');
                const data = await res.json();
                setDashboard(data);
            } catch (err) {
                console.error('❌ Error cargando dashboard:', err);
                router.push('/auth/signin');
            } finally {
                setLoading(false);
            }
        };

        fetchUserAndDashboard();
    }, []);

    if (loading) {
        return <p className="text-center text-green-700 mt-20 text-xl">Cargando tu panel...</p>;
    }

    return (
        <section className="min-h-screen bg-green-50 px-6 py-10 font-sans">
            <div className="max-w-6xl mx-auto space-y-8">
                {/* Header */}
                <div className="bg-white shadow-lg rounded-xl p-6 flex flex-col md:flex-row justify-between items-center border border-green-200">
                    <div>
                        <h1 className="text-3xl font-bold text-green-800">Hola, {user?.name}</h1>
                        <p className="text-gray-600 mt-1">Bienvenido a tu espacio saludable 🌿</p>
                    </div>
                    <button className="mt-4 md:mt-0 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition">
                        Editar perfil
                    </button>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-green-100 p-6 rounded-xl text-center shadow border">
                        <h3 className="text-lg font-semibold text-green-700">Puntos totales</h3>
                        <p className="text-4xl font-bold text-green-900 mt-2">{dashboard?.points ?? 0}</p>
                    </div>
                    <div className="bg-green-100 p-6 rounded-xl text-center shadow border">
                        <h3 className="text-lg font-semibold text-green-700">Nivel</h3>
                        <p className="text-4xl font-bold text-green-900 mt-2">{dashboard?.level ?? 1} 🧘</p>
                    </div>
                    <div className="bg-green-100 p-6 rounded-xl text-center shadow border">
                        <h3 className="text-lg font-semibold text-green-700">Retos completados</h3>
                        <p className="text-4xl font-bold text-green-900 mt-2">{dashboard?.completed_challenges ?? 0}</p>
                    </div>
                </div>

                {/* Weekly Progress */}
                <div className="bg-white rounded-xl shadow p-6 border border-green-200">
                    <h2 className="text-xl font-bold text-green-800 mb-4">Progreso semanal</h2>
                    <div className="grid grid-cols-7 gap-3 text-center">
                        {['L', 'M', 'X', 'J', 'V', 'S', 'D'].map((d, i) => (
                            <div key={i} className={`p-4 rounded-full font-semibold ${i < 5 ? 'bg-green-500 text-white' : 'bg-gray-200'}`}>
                                {d}
                            </div>
                        ))}
                    </div>
                </div>

                {/* Reminders */}
                <div className="bg-white rounded-xl shadow p-6 border border-green-200">
                    <h2 className="text-xl font-bold text-green-800 mb-4">Recordatorios activos</h2>
                    <ul className="space-y-3">
                        {(dashboard?.reminders ?? []).map((r, i) => (
                            <li key={i} className="bg-green-100 text-green-900 p-4 rounded-lg shadow-sm">{r}</li>
                        ))}
                    </ul>
                </div>

                {/* Tip */}
                <div className="bg-white rounded-xl shadow p-6 border border-green-200">
                    <h2 className="text-xl font-bold text-green-800 mb-4">Consejo del día 🌱</h2>
                    <p className="text-gray-700 leading-relaxed">
                        {dashboard?.tip ?? 'Respira profundo, cuida tu cuerpo y tu mente.'}
                    </p>
                </div>
            </div>
        </section>
    );
}
