'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Cookies from 'js-cookie';
import { useUser } from '@/context/UserContext';

export default function SignIn() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const router = useRouter();
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const { setUser } = useUser();

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(null);
        setIsLoading(true);

        try {
            // Get CSRF cookie first
            const csrfResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/sanctum/csrf-cookie`, {
                method: 'GET',
                credentials: 'include',
                headers: {
                    'Accept': 'application/json',
                }
            });

            if (!csrfResponse.ok) {
                console.error('Failed to fetch CSRF cookie:', await csrfResponse.text());
                setError('Error obteniendo el token CSRF');
                setIsLoading(false);
                return;
            }

            const csrfToken = Cookies.get('XSRF-TOKEN');
            if (!csrfToken) {
                console.error('CSRF token not found in cookies');
                setError('No se pudo obtener el token CSRF');
                setIsLoading(false);
                return;
            }

            const loginResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-XSRF-TOKEN': decodeURIComponent(csrfToken),
                },
                credentials: 'include',
                body: JSON.stringify({ email, password }),
            });

            const data = await loginResponse.json();

            if (loginResponse.ok) {
                // After successful login, verify the user is authenticated
                const userResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/user`, {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                    }
                });

                if (userResponse.ok) {
                    const userData = await userResponse.json();

                    if (userData && userData.user) {
                        setUser(userData.user);
                        localStorage.setItem('auth_user', JSON.stringify(userData.user));

                        // Small delay to ensure state updates
                        setTimeout(() => {
                            router.push('/dashboard');
                        }, 100);
                    } else {
                        setError('Datos de usuario incompletos');
                        console.error('User data incomplete:', userData);
                    }
                } else {
                    setError('Error verificando autenticación');
                    console.error('User verification failed:', await userResponse.text());
                }
            } else {
                setError(data.message || 'Error al iniciar sesión');
                console.error('Login failed:', data);
            }
        } catch (err) {
            console.error('Login error:', err);
            setError('Fallo en la conexión con el servidor');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <section className="min-h-screen bg-green-50 flex items-center justify-center px-4">
            <div className="max-w-md w-full bg-white shadow-lg rounded-lg p-8">
                <h2 className="text-2xl font-bold text-green-700 mb-6 text-center">Iniciar sesión</h2>
                {error && <p className="text-red-500 text-center mb-4">{error}</p>}
                <form onSubmit={handleLogin} className="space-y-4">
                    <input
                        type="email"
                        name="email"
                        placeholder="Correo electrónico"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-4 py-2 border rounded-lg"
                        required
                    />
                    <input
                        type="password"
                        name="password"
                        placeholder="Contraseña"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full px-4 py-2 border rounded-lg"
                        required
                    />
                    <button
                        type="submit"
                        className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 disabled:bg-green-400"
                        disabled={isLoading}
                    >
                        {isLoading ? 'Iniciando sesión...' : 'Iniciar sesión'}
                    </button>
                </form>
                <p className="mt-4 text-center text-sm">
                    ¿No tienes cuenta?{' '}
                    <Link href="/auth/register" className="text-green-600 hover:underline">
                        Regístrate aquí
                    </Link>
                </p>
            </div>
        </section>
    );
}