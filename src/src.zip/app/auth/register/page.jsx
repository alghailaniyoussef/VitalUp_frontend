'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function RegisterPage() {
    const router = useRouter();
    const [form, setForm] = useState({
        name: '',
        email: '',
        password: '',
        password_confirmation: '',
    });
    const [error, setError] = useState(null);

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleRegister = async (e) => {
        e.preventDefault();

        try {
            const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(form),
            });

            if (res.ok) {
                router.push('/auth/signin');
            } else {
                const data = await res.json();
                setError(data.message || 'Error al registrarse');
            }
        } catch (err) {
            setError('Fallo en la conexión con el servidor');
        }
    };

    return (
        <section className="min-h-screen bg-green-50 flex items-center justify-center px-4">
            <div className="max-w-md w-full bg-white shadow-lg rounded-lg p-8">
                <h2 className="text-2xl font-bold text-green-700 mb-6 text-center">Registrarse</h2>
                {error && <p className="text-red-500 text-center mb-4">{error}</p>}
                <form onSubmit={handleRegister} className="space-y-4">
                    <input name="name" value={form.name} onChange={handleChange} type="text" placeholder="Nombre" required className="w-full px-4 py-2 border rounded-lg" />
                    <input name="email" value={form.email} onChange={handleChange} type="email" placeholder="Correo electrónico" required className="w-full px-4 py-2 border rounded-lg" />
                    <input name="password" value={form.password} onChange={handleChange} type="password" placeholder="Contraseña" required className="w-full px-4 py-2 border rounded-lg" />
                    <input name="password_confirmation" value={form.password_confirmation} onChange={handleChange} type="password" placeholder="Confirmar contraseña" required className="w-full px-4 py-2 border rounded-lg" />
                    <button type="submit" className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">Registrarse</button>
                </form>
                <p className="mt-4 text-center text-sm">
                    ¿Ya tienes una cuenta?{' '}
                    <Link href="/auth/signin" className="text-green-600 hover:underline">
                        Inicia sesión
                    </Link>
                </p>
            </div>
        </section>
    );
}
