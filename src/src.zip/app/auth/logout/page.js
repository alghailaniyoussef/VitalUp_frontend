export async function logout() {
    try {
        await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/logout`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            }
        });

        // Clear any stored tokens if you're using them
        // localStorage.removeItem('auth_token');

        window.location.href = '/';
    } catch (error) {
        console.error("Logout error:", error);
        window.location.href = '/';
    }
}