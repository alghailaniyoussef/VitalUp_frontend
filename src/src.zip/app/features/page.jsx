import Image from "next/image";
import Link from "next/link";

export default function Features() {
    return (
        <section className="px-8 py-20 bg-white">
            <h3 className="text-3xl font-semibold text-center text-green-800 mb-12">¿Qué ofrecemos?</h3>
            <div className="grid md:grid-cols-3 gap-10">
                <div className="text-center">
                    <Image src="/images/notification.png" alt="Recordatorios" width={100} height={100} className="mx-auto mb-4" />
                    <h4 className="text-xl font-bold">Recordatorios inteligentes</h4>
                    <p className="text-gray-600">Recibe correos según tu frecuencia preferida, totalmente personalizados.</p>
                </div>
                <div className="text-center">
                    <Image src="/images/progress.png" alt="Progreso" width={100} height={100} className="mx-auto mb-4" />
                    <h4 className="text-xl font-bold">Seguimiento de progreso</h4>
                    <p className="text-gray-600">Gana puntos, sube de nivel y desbloquea recompensas.</p>
                </div>
                <div className="text-center">
                    <Image src="/images/community.png" alt="Comunidad" width={100} height={100} className="mx-auto mb-4" />
                    <h4 className="text-xl font-bold">Desafíos comunitarios</h4>
                    <p className="text-gray-600">Únete a otros en retos semanales y mensuales.</p>
                </div>
            </div>
        </section>
    );
}
