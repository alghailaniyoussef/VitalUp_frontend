'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useUser } from '@/context/UserContext';
import { useEffect, useState } from 'react';

export default function Navigation() {
    const { user, setUser } = useUser();
    const router = useRouter();
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user !== undefined) {
            setLoading(false);
        }
    }, [user]);

    const handleLogout = async () => {
        await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/logout`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            }
        });

        setUser(null);
        router.push('/');
    };
    return (
        <header className="flex items-center justify-between px-8 py-4 shadow-md">
            <h1 className="text-2xl font-bold text-green-600">Healthy Notifications</h1>
            <nav className="space-x-6">
                <Link href="/" className="text-green-600 hover:underline">Inicio</Link>
                <Link href="/features" className="text-green-600 hover:underline">Características</Link>
                <Link href="/about" className="text-green-600 hover:underline">Sobre Nosotros</Link>

                {loading ? (
                    <span className="text-gray-400">Cargando...</span>
                ) : user ? (
                    <>
                        {console.log("✅ USER IS LOGGED IN")}
                        <Link href="/dashboard" className="text-green-600 hover:underline">Dashboard</Link>
                        <span className="text-gray-700">Bienvenido, {user.name}</span>
                        <button onClick={handleLogout} className="text-red-600 hover:underline">
                            Cerrar sesión
                        </button>
                    </>
                ) : (
                    <>
                        {console.log("⛔ NO USER")}
                        <Link href="/auth/signin" className="text-green-600 hover:underline">Iniciar Sesión</Link>
                        <Link href="/auth/register" className="text-green-600 hover:underline">Registrarse</Link>
                    </>
                )}
            </nav>
        </header>
    );
}
