'use client';

import './globals.css';
import Navigation from './components/Navigation';
import { UserProvider } from '@/context/UserContext';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body className="bg-gray-100 text-gray-900 font-sans">
        <UserProvider>
          <main className="min-h-screen bg-white text-gray-800">
            <Navigation />
            {children}
          </main>
        </UserProvider>
      </body>
    </html>
  );
}